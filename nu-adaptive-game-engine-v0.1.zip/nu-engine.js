/* N.U Lightweight Adaptive Game Engine
 * No external libraries. Canvas 2D. Conservative startup + runtime adaptation.
 */
(function (global) {
  "use strict";

  function detectDevice() {
    const nav = navigator || {};
    const conn = nav.connection || nav.mozConnection || nav.webkitConnection || {};
    const memory = Number(nav.deviceMemory) || null;
    const cores = Number(nav.hardwareConcurrency) || null;
    const reducedMotion = !!(global.matchMedia &&
      global.matchMedia("(prefers-reduced-motion: reduce)").matches);
    const saveData = !!conn.saveData;
    const width = Math.max(1, global.innerWidth || 1);
    const height = Math.max(1, global.innerHeight || 1);

    let tier = "balanced";
    if (saveData || reducedMotion || (memory && memory <= 2) || (cores && cores <= 2)) {
      tier = "low";
    } else if ((memory && memory >= 8) && (cores && cores >= 8)) {
      tier = "high";
    }

    return {
      tier, memoryGB: memory, logicalCores: cores,
      saveData, reducedMotion, screenWidth: width, screenHeight: height,
      pixelRatio: Math.min(global.devicePixelRatio || 1, 2)
    };
  }

  function createEngine(options) {
    options = options || {};
    const canvas = options.canvas;
    const render = options.render;
    if (!canvas || typeof canvas.getContext !== "function") {
      throw new Error("N.U Engine: a valid canvas is required.");
    }
    if (typeof render !== "function") {
      throw new Error("N.U Engine: provide a render(context, state) function.");
    }

    const ctx = canvas.getContext("2d", { alpha: false, desynchronized: true });
    if (!ctx) throw new Error("N.U Engine: Canvas 2D is not available.");

    const device = detectDevice();
    const presets = {
      low:      { scale: 0.65, fps: 30, effects: false },
      balanced: { scale: 0.80, fps: 45, effects: false },
      high:     { scale: 1.00, fps: 60, effects: true }
    };
    const preset = presets[device.tier];
    const state = {
      tier: device.tier,
      scale: preset.scale,
      targetFPS: preset.fps,
      effects: preset.effects,
      fps: 0,
      frameTime: 0,
      renderTime: 0,
      quality: "auto",
      running: false
    };

    let rafId = 0, lastFrame = 0, lastSample = 0;
    let frames = 0, sampleFrameTime = 0, sampleRenderTime = 0;
    let accumulator = 0, lastAdjust = 0;
    let width = 1, height = 1;
    const minScale = 0.45, maxScale = 1;
    const minFPS = 24, maxFPS = 60;
    const step = 1000 / 60;
    const userState = options.state || {};

    function resize() {
      const cssW = Math.max(1, canvas.clientWidth || global.innerWidth || 1);
      const cssH = Math.max(1, canvas.clientHeight || global.innerHeight || 1);
      const dpr = Math.min(global.devicePixelRatio || 1, 2);
      width = Math.round(cssW * dpr * state.scale);
      height = Math.round(cssH * dpr * state.scale);
      if (canvas.width !== width) canvas.width = width;
      if (canvas.height !== height) canvas.height = height;
      ctx.setTransform(1, 0, 0, 1, 0, 0);
    }

    function adapt(now) {
      if (now - lastAdjust < 2500) return;
      lastAdjust = now;
      const avgFrame = frames ? sampleFrameTime / frames : 0;
      const avgRender = frames ? sampleRenderTime / frames : 0;
      const slow = avgFrame > (1000 / Math.max(1, state.targetFPS)) * 1.25 ||
                   avgRender > 18;
      const healthy = avgFrame > 0 &&
                      avgFrame < (1000 / Math.max(1, state.targetFPS)) * 0.82 &&
                      avgRender < 9;

      if (state.quality === "auto") {
        if (slow) {
          state.scale = Math.max(minScale, state.scale - 0.08);
          state.targetFPS = Math.max(minFPS, state.targetFPS - 5);
          state.effects = false;
          resize();
        } else if (healthy) {
          state.scale = Math.min(maxScale, state.scale + 0.03);
          state.targetFPS = Math.min(maxFPS, state.targetFPS + 2);
          if (state.scale >= 0.9 && state.targetFPS >= 55) state.effects = true;
          resize();
        }
      }
      frames = 0;
      sampleFrameTime = 0;
      sampleRenderTime = 0;
    }

    function frame(now) {
      if (!state.running) return;
      rafId = global.requestAnimationFrame(frame);
      if (!lastFrame) lastFrame = now;
      const elapsed = Math.min(100, now - lastFrame);
      lastFrame = now;
      accumulator += elapsed;
      const interval = 1000 / state.targetFPS;
      if (accumulator < interval) return;
      accumulator %= interval;

      const renderStart = (global.performance && performance.now) ? performance.now() : now;
      try {
        render(ctx, {
          width, height, delta: Math.min(elapsed / 1000, 0.05),
          device, engine: state, state: userState
        });
      } catch (err) {
        stop();
        console.error("N.U Engine render error:", err);
        if (typeof options.onError === "function") options.onError(err);
        return;
      }
      const renderEnd = (global.performance && performance.now) ? performance.now() : now;
      const renderCost = renderEnd - renderStart;

      frames++;
      sampleFrameTime += elapsed;
      sampleRenderTime += renderCost;
      state.frameTime = elapsed;
      state.renderTime = renderCost;
      state.fps = elapsed > 0 ? Math.round(1000 / elapsed) : 0;
      adapt(now);
      if (typeof options.onStats === "function") options.onStats(getStats());
    }

    function start() {
      if (state.running) return;
      state.running = true;
      lastFrame = 0;
      resize();
      rafId = global.requestAnimationFrame(frame);
    }

    function stop() {
      state.running = false;
      if (rafId) global.cancelAnimationFrame(rafId);
      rafId = 0;
    }

    function setQuality(mode) {
      if (!["auto", "low", "balanced", "high"].includes(mode)) return;
      state.quality = mode;
      if (mode !== "auto") {
        const p = presets[mode];
        state.scale = p.scale;
        state.targetFPS = p.fps;
        state.effects = p.effects;
        resize();
      }
    }

    function getStats() {
      return {
        device: Object.assign({}, device),
        tier: state.tier,
        qualityMode: state.quality,
        renderScale: Number(state.scale.toFixed(2)),
        targetFPS: state.targetFPS,
        measuredFPS: state.fps,
        renderTimeMs: Number(state.renderTime.toFixed(2)),
        effectsEnabled: state.effects,
        running: state.running
      };
    }

    global.addEventListener("resize", resize, { passive: true });
    resize();

    return {
      start, stop, setQuality, getStats,
      get context() { return ctx; },
      get canvas() { return canvas; }
    };
  }

  global.NUGameEngine = {
    create: createEngine,
    detectDevice
  };
})(window);
