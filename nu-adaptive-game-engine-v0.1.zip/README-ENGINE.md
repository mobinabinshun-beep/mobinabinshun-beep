# N.U Adaptive Game Engine — Version 0.1

A tiny, dependency-free HTML Canvas runtime for N.U browser games.

## Upload these files

Upload `nu-engine.js` and `engine-demo.html` to the root of your GitHub Pages repository.

Open the test page at:

`https://mobinabinshun-beep.github.io/mobinabinshun-beep/engine-demo.html`

## Use it in a game

1. Add a canvas to your HTML:

```html
<canvas id="game" style="width:100%;height:500px"></canvas>
<script src="nu-engine.js"></script>
<script>
const engine = NUGameEngine.create({
  canvas: document.getElementById("game"),
  render(ctx, info) {
    // Draw your game here.
    // info.width and info.height are the internal canvas dimensions.
    // info.delta is elapsed time in seconds.
    // info.engine.effects tells you whether optional effects should run.
    // info.state is your own optional game state.
  }
});
engine.start();
</script>
```

2. Optional quality controls:

```js
engine.setQuality("auto");      // automatic adjustment
engine.setQuality("low");
engine.setQuality("balanced");
engine.setQuality("high");
console.log(engine.getStats());
```

## What it does

- Starts with conservative settings on devices that report limited resources.
- Measures frame intervals and render callback time.
- In automatic mode, lowers render resolution and target frame rate when performance is poor.
- Gradually raises quality when performance remains healthy.
- Uses Canvas 2D and no external libraries.

## Important limits

- Browsers do not expose a complete or reliable measurement of device capability.
- `deviceMemory` and hardware core counts may be missing or approximate.
- This engine cannot guarantee a fixed CPU/GPU load or prevent every game from becoming heavy.
- The game itself must be written efficiently. Avoid large assets, excessive particles, huge loops, and unnecessary DOM updates.
- This first version does not yet include WebGL, asset streaming, multiplayer, physics, or a game editor.
- Test on real phones and computers before publishing.

N.U — Niroo Universe
